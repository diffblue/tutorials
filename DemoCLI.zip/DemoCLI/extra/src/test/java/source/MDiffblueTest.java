package source;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.source.M;

class MDiffblueTest {
  /**
  * Method under test: default or parameterless constructor of {@link M}
  */
  @Test
  void testConstructor() {
    // Arrange, Act and Assert
    assertEquals(1, (new M()).m);
  }
}

