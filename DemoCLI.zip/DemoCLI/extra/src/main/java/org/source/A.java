package org.source;

public class A {
    int a = 2;
    int method(double x) {
        return (int) (a * x);
    }
}
