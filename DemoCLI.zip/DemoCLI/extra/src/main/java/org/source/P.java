package org.source;

public class P {
    int p = 6;
    N obj = new N();
}
