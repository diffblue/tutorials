package org.source;

public class N {
    int n = 4;
    M obj = new M();
}
