package org.source;

public class M {
    int m = 2;
}
