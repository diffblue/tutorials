package files;

import java.io.File;
import java.nio.file.Path;

public class Harmful {

    File directoryToBeDeleted = new File("C:\\Users\\cbontoiu\\Desktop\\DiffblueTutorials\\DemoCLI\\extra\\src\\main\\resources");

    public void deleteRecursively(final Path root) {
        final File[] contents = directoryToBeDeleted.listFiles();
        if (contents != null) {
            for (final File file : contents) {
                file.delete();
            }
        }
    }
}


