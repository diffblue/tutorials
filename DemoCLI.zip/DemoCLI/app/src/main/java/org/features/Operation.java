package org.features;

public record Operation() {
}
