package org.action;

import java.io.File;

public class MainApp {

    File directoryToBeDeleted = new File("C:\\Users\\cbontoiu\\Desktop\\DiffblueTutorials\\DemoCLI\\app\\src\\main\\resources");

    public static void main(String[] args) {
        MainApp obj = new MainApp();
        final File[] contents = obj.directoryToBeDeleted.listFiles();
        System.out.println("contents has" + contents.length + " files:");
        for (final File file : contents) {
            System.out.println(file.toString());
        }

    }
}
