module DemoCLI.app {
    requires DemoCLI.common;
}