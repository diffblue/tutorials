module DemoCLI.common {
    exports org.utils;
}