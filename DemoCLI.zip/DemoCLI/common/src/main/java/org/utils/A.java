package org.utils;

class A implements I {
    @Override
    public double function(double val) {
        return 2 * val;
    }
}