package org.utils;

public class C {

    private static double value = 2 * I.getHeight(0.1);
}
