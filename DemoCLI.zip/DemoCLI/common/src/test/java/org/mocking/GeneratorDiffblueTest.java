package org.mocking;

import org.junit.jupiter.api.Test;

class GeneratorDiffblueTest {
  /**
   * Method under test: {@link Generator#makeString()}
   */
  @Test
  void testMakeString() {
    // TODO: Complete this test.
    //   Diffblue AI was unable to find a test

    // Arrange and Act
    (new Generator()).makeString();
  }

  /**
  * Method under test: default or parameterless constructor of {@link Generator}
  */
  @Test
  void testConstructor() {
    // TODO: Complete this test.
    //   Reason: R002 Missing observers.
    //   Diffblue Cover was unable to create an assertion.
    //   There are no fields that could be asserted on.

    // Arrange and Act
    new Generator();
  }
}

